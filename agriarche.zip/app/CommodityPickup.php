<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommodityPickup extends Model
{
    protected $table = 'commodity_pickup';
}
