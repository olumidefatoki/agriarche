
<?php $__env->startSection('title'); ?>
Mapping | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
<li><a href=active>Mapping</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Mapping</h3>
                    <ul class="panel-controls">
                        <a href="<?php echo e(route('mapping.create')); ?>">
                            <button class="m-0 btn btn-success" style="float:right;">Add New Mapping </button>
                        </a>
                    </ul>
                </div>
                <div class="panel-body">
                    <div style="overflow-x:auto;">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Buyer Name</th>
                                    <th>Delivery State</th>
                                    <th>Commodity</th>
                                    <th>Aggregator Name</th>
                                    <th>Coupon Price</th>
                                    <th>Strike Price(NGN)</th>
                                    <th>Creation Date</th>
                                    <th>Last Updated Date</th>
                                    <th nowrap>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(count($orderMappings) > 0): ?>
                                <?php $__currentLoopData = $orderMappings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderMapping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($orderMapping->buyerOrder->buyer->name); ?></td>
                                    <td><?php echo e($orderMapping->buyerOrder->state->name); ?></td>
                                    <td><?php echo e($orderMapping->buyerOrder->commodity->name); ?></td>
                                    <td><?php echo e($orderMapping->aggregator->name); ?> </td>
                                    <td>&#8358;<?php echo e($orderMapping->buyerOrder->coupon_price); ?></td>
                                    <td>&#8358;<?php echo e($orderMapping->strike_price); ?></td>
                                    <td><?php echo e($orderMapping->created_at); ?></td>
                                    <td><?php echo e($orderMapping->updated_at); ?></td>
                                    <td nowrap>
                                        <a href="<?php echo e(route('mapping.edit',$orderMapping)); ?>"
                                        class="btn btn-sm btn-info" 
                                        data-toggle="tooltip" data-placement="top" title="Edit Order">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="10" style="text-align: center;">
                                        No Records Found
                                    </td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/mapping/index.blade.php ENDPATH**/ ?>