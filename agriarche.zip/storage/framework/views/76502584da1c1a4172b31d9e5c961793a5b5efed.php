
<?php $__env->startSection('title'); ?>
Buyer index | Agriarche 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>                    
                    <li><a href="#">Buyer</a></li>
                    <li class="active">Create</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <h2 class="panel-title">Buyer</h2>                                                                   
                                </div>
                                <div class="col-md-2"></div>
                                <div class="col-md-6">
                                <div class=" panel-body">
                                    <table class="table table-bordered table-striped">
                                        <tbody>
                                            <tr>
                                                <td width="50%">Buyer Name</td>
                                                <td><?php echo e($buyer->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Address</td>
                                                <td><?php echo e($buyer->address); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person First Name</td>
                                                <td><?php echo e($buyer->contact_person_first_name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person Last Name</td>
                                                <td><?php echo e($buyer->contact_person_last_name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person Email</td>
                                                <td><?php echo e($buyer->contact_person_email); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person Phone Number</td>
                                                <td><?php echo e($buyer->contact_person_phone_number); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>State</td>
                                                <td><?php echo e($buyer->state->name); ?></td>
                                            </tr> 
                                                                                    
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->
                        </div>                        
                    </div>                                
                    
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/buyer/show.blade.php ENDPATH**/ ?>