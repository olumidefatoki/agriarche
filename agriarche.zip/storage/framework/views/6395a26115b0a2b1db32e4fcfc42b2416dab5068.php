
<?php $__env->startSection('title'); ?>
Logistics | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
<li><a href=active>Logistics</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Logistics</h3>
                    <ul class="panel-controls">
                        <a href="<?php echo e(route('delivery.create')); ?>">
                            <button class="m-0 btn btn-success" style="float:right;">Add New Delivery </button>
                        </a>
                    </ul>
                </div>
                <div class="panel-body">
                    <div style="overflow-x:auto;">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                <th nowrap>Logistics Code</th>
                                    <th nowrap>Buyer</th>
                                    <th nowrap>Aggregator</th>
                                    <th nowrap>Delivery Point</th>
                                    <th nowrap>Commodity</th>
                                    <th nowrap>Total Amount</th>
                                    <th nowrap>Payable Amount</th>
                                    <th nowrap>Quantity Delivered(KG)</th>
                                    <th nowrap>Status</th>
                                    <th  nowrap>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($deliveries) > 0): ?>
                                <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($delivery->logistics->code); ?></td>
                                    <td><?php echo e($delivery->logistics->buyerOrder->buyer->name); ?></td>
                                    <td><?php echo e($delivery->logistics->aggregator->name); ?></td>
                                    <td><?php echo e($delivery->logistics->buyerOrder->state->name); ?></td>
                                    <td><?php echo e($delivery->logistics->buyerOrder->commodity->name); ?></td>
                                    <td>&#8358; <?php echo e(number_format($delivery->quantity_of_bags_accepted * $delivery->strike_price,2)); ?></td>
                                    <td>&#8358; <?php echo e(number_format($delivery->quantity_of_bags_accepted * ($delivery->strike_price - $delivery->discounted_price),2)); ?></td>
                                    <td><?php echo e(number_format($delivery->quantity_of_bags_accepted,2)); ?></td>
                                    
                                    <td><?php echo e($delivery->status->name); ?></td>
                                    <td   nowrap><a href="<?php echo e(route('delivery.edit',$delivery)); ?>" class="btn btn-sm btn-info" data-toggle="tooltip" data-placement="top" title="Edit Delivery">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <a href="<?php echo e(route('delivery.show',$delivery)); ?>" class="btn btn-sm btn-info" data-toggle="tooltip" data-placement="top" title="Open Delivery">
                                            <i class="glyphicon glyphicon-eye-open"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="9" style="text-align: center;">
                                        No Records Found
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <?php echo e($deliveries->links()); ?>

                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/delivery/index.blade.php ENDPATH**/ ?>