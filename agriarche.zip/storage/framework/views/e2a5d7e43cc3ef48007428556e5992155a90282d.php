
<?php $__env->startSection('title'); ?>
Logistics | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
<li><a href=active>Logistics</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">
            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Logistics</h3>
                    <ul class="panel-controls">
                        <a href="<?php echo e(route('logistics.create')); ?>">
                            <button class="m-0 btn btn-success" style="float:right;">Add New Logistics </button>
                        </a>
                    </ul>
                </div>
                <div class="panel-body">
                    <div style="overflow-x:auto;">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th nowrap>Code</th>
                                    <th nowrap>Buyer</th>
                                    <th nowrap>Delivery state</th>
                                    <th nowrap>Aggregator</th>
                                    <th>Commodity</th>
                                    <th nowrap>Quantity</th>
                                    <th nowrap>No of Bags</th>
                                    <th nowrap>Logisitics Company</th>
                                    <th nowrap>Truck No</th>
                                    <th nowrap>Driver Name</th>
                                    <th nowrap>Driver Phone</th>
                                    <th nowrap>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(count($Logistics) > 0): ?>
                                <?php $__currentLoopData = $Logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($logistics->code); ?></td>
                                    <td><?php echo e($logistics->buyerOrder->buyer->name); ?> </td>
                                    <td><?php echo e($logistics->buyerOrder->state->name); ?> </td>
                                    <td><?php echo e($logistics->aggregator->name); ?></td>
                                    <td><?php echo e($logistics->buyerOrder->commodity->name); ?></td>
                                    <td><?php echo e(number_format($logistics->quantity,2)); ?></td>
                                    <td><?php echo e(number_format($logistics->no_of_bags)); ?></td>
                                    <td><?php echo e($logistics->logisticsCompany->name); ?></td>
                                    <td><?php echo e($logistics->truck_number); ?></td>
                                    <td><?php echo e($logistics->driver_name); ?></td>
                                    <td><?php echo e($logistics->driver_phone_number); ?></td>
                                    <td><?php echo e($logistics->status->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('logistics.edit',$logistics)); ?>" class="btn btn-sm btn-info" 
                                        data-toggle="tooltip" data-placement="top" title="Edit Aggregator">
                                            <i class="fa fa-edit"></i>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="10" style="text-align: center;">
                                        No Records Found
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <?php echo e($Logistics->links()); ?>

                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/logistics/index.blade.php ENDPATH**/ ?>