
<?php $__env->startSection('title'); ?>
Create Delivery | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>
<li><a href="#">Delivery </a></li>
<li class="active">Create</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <div class="block">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><strong>Delivery</strong></h3>

                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('delivery.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group <?php $__errorArgs = ['logistics'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Code</label>
                                <div class="col-md-6">
                                    <select class="form-control select" name="logistics">
                                    <option> Select an Code</option>
                                        <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($logistic->id); ?>"><?php echo e($logistic->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Buyer:</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="buyer" class="form-control" id="buyer" disabled/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Aggregator</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="aggregator" class="form-control" disabled />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Commodity</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="commodity" class="form-control" disabled />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Delivery State</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="delivery_state" class="form-control" disabled />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Logistics Company</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="logistics_company" class="form-control" disabled />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Truck No:</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="truck_number" class="form-control" disabled />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Truck Quantity</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="truck_quantity" class="form-control" disabled />
                                </div>
                            </div>
                            
                            <div class="form-group <?php $__errorArgs = ['discounted_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Discounted Price:</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="discounted_price" class="form-control" value="<?php echo e(old('discounted_price')); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['number_of_bags_accepted'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Number Of Bags Accepted:</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="number_of_bags_accepted" class="form-control" value="<?php echo e(old('number_of_bags_accepted')); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['quantity_of_bags_accepted'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Qty Of Bags Accepted(kg):</label>
                                <div class="col-md-6">
                                    <input type="text" name="quantity_of_bags_accepted" class="form-control" value="<?php echo e(old('quantity_of_bags_accepted')); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['number_of_bags_rejected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Number Of Bags Rejected:</label>
                                <div class="col-md-6">
                                    <input type="text" name="number_of_bags_rejected" class="form-control" value="<?php echo e(old('number_of_bags_rejected')); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['quantity_of_bags_rejected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Qty Of Bags Rejected(kg):</label>
                                <div class="col-md-6">
                                    <input type="text" name="quantity_of_bags_rejected" class="form-control" value="<?php echo e(old('quantity_of_bags_rejected')); ?>" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">status</label>
                                <div class="col-md-6">
                                    <select class="form-control select" name="status">
                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sta->id); ?>"><?php echo e($sta->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group <?php $__errorArgs = ['waybill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Waybill:</label>
                                <div class="col-md-6">
                                    <input name='waybill' type="file" multiple id="file-simple" class="form-control" />
                                </div>
                            </div>

                            <div class="btn-group pull-right">
                                <button class="btn btn-success" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/fileinput/fileinput.min.js')); ?>"></script>

    <script>
        $(function() {
            $("#file-simple").fileinput({
                showUpload: false,
                showCaption: false,
                browseClass: "btn btn-danger",
                fileType: "any"
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('select[name="logistics"]').on('change', function() {
                var logisticsId = $(this).val();
                if (logisticsId) {
                    $.ajax({
                        url: '<?php echo e(url('/logistics/order/')); ?>' + '/' + logisticsId,
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                            $('select[name="aggregator_id"]').empty();
                            console.log(data);
                            console.log(data.buyer);
                            $('input[name="buyer"]').val(data.buyer);
                            $('input[name="commodity"]').val(data.commodity);
                            $('input[name="aggregator"]').val(data.aggregator);
                            $('input[name="truck_number"]').val(data.truck_number);
                            $('input[name="truck_quantity"]').val(data.truck_quantity);
                            $('input[name="delivery_state"]').val(data.state);
                            $('input[name="logistics_company"]').val(data.logistics_company);
                        }
                    });
                } 
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/delivery/create.blade.php ENDPATH**/ ?>