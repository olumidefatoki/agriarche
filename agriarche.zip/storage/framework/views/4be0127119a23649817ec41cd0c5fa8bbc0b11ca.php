
<?php $__env->startSection('title'); ?>
Logistics company | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
<li><a href=active>Logistics company</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">
    <div class="row">
        <div class="col-md-12">
            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Logistics company</h3>
                    <ul class="panel-controls">
                        <a href="<?php echo e(route('logisticsCompany.create')); ?>">
                            <button class="m-0 btn btn-success" style="float:right;">Add New Logistics company </button>
                        </a>
                    </ul>
                </div>
                <div class="panel-body">
                    <div style="overflow-x:auto;">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Contact Person Name</th>
                                    <th>Contact Person Phone Number</th>
                                    <th>State</th>
                                    <th>Creation Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(count($logisticsCompanies) > 0): ?>
                                <?php $__currentLoopData = $logisticsCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logisticsCompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($logisticsCompany->name); ?> </td>
                                    <td><?php echo e($logisticsCompany->address); ?> </td>
                                    <td><?php echo e($logisticsCompany->contact_person_name); ?> </td>
                                    <td><?php echo e($logisticsCompany->contact_person_phone_number); ?></td>
                                    <td><?php echo e($logisticsCompany->state->name); ?></td>
                                    <td><?php echo e($logisticsCompany->created_at); ?> </td>
                                    <td>
                                        <a href="<?php echo e(route('logisticsCompany.edit',$logisticsCompany)); ?>" class="btn btn-sm btn-info" 
                                        data-toggle="tooltip" data-placement="top" title="Edit">
                                            <i class="fa fa-edit"></i>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="10" style="text-align: center;">
                                        No Records Found
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <?php echo e($logisticsCompanies->links()); ?>

                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/logistics_company/index.blade.php ENDPATH**/ ?>