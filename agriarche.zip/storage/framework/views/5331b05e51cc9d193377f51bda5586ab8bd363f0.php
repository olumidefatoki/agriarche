
<?php $__env->startSection('title'); ?>
Logistics | Agriarche 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>                    
                    <li><a href=active>Logistics</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <h3 class="panel-title">Logistics</h3>
                                    <ul class="panel-controls">
                                        <a href="<?php echo e(route('logisticsCompany.create')); ?>">
                                            <button class="m-0 btn btn-success" style="float:right;">Add New Logistics company </button>
                                        </a>
                                    </ul>                                
                                </div>
                                <div class="panel-body">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Food Processor</th>
                                                <th>Aggregator</th>
                                                <th>Commodity</th>
                                                <th>Truck No</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $CommodityPickups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CommodityPickup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td> </td>
                      <td></td>
                      <td></td>
                      <td></td>
                                                <td></td>
                                                <td><a href="<?php echo e(route('logisticsCompany.show',$logisticsCompany)); ?>"><i class="fa fa-plus-circle"></i> VIEW MORE </a></td>
                                            </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </tbody>
                                    </table>
                                    <div>
                                    <?php echo e($CommodityPickups->links()); ?>

                                    </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->


                        </div>
                    </div>                                
                    
                </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/commodity_pickup/index.blade.php ENDPATH**/ ?>