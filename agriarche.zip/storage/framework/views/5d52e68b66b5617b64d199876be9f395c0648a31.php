
<?php $__env->startSection('title'); ?>
logistics details | Agriarche 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>                    
                    <li><a href="#">logistics</a></li>
                    <li class="active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <h2 class="panel-title">logistics</h2>                                                                   
                                </div>
                                <div class="col-md-2"></div>
                                <div class="col-md-6">
                                <div class=" panel-body">
                                    <table class="table table-bordered table-striped">
                                        <tbody>
                                            <tr>
                                                <td width="50%">Order Code</td>
                                                <td><?php echo e($logistics->buyer_order_id); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Buyer Name</td>
                                                <td><?php echo e($logistics->buyerOrder->buyer->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Aggregator Name</td>
                                                <td><?php echo e($logistics->aggregator->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Commodity</td>
                                                <td><?php echo e($logistics->buyerOrder->commodity->namee); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Number Of Bags</td>
                                                <td><?php echo e($logistics->no_of_bags); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Quantity</td>
                                                <td><?php echo e($logistics->quantity); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Logistics Company</td>
                                                <td><?php echo e($logistics->driver_phone_number); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Driver Name</td>
                                                <td><?php echo e($logistics->driver_name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Driver Phone Number</td>
                                                <td><?php echo e($logistics->driver_phone_number); ?></td>
                                            </tr> 
                                                                                    
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->
                        </div>                        
                    </div>                                
                    
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/logistics/show.blade.php ENDPATH**/ ?>