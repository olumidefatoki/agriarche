
<?php $__env->startSection('title'); ?>
Order | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
<li><a href=active>Order</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Order</h3>
                    <ul class="panel-controls">
                        <a href="<?php echo e(route('order.create')); ?>">
                            <button class="m-0 btn btn-success" style="float:right;">Add New Order </button>
                        </a>
                    </ul>
                </div>
                <div class="panel-body">
                    <div style="overflow-x:auto;">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th nowrap>Code</th>
                                    <th nowrap>Buyer</th>
                                    <th nowrap>Commodity</th>
                                    <th nowrap>Coupon Price </th>
                                    <th nowrap>Order Qty(MT)</th>
                                    <th nowrap>State</th>
                                    <th nowrap>Delivery Location</th>                                   
                                    <th nowrap>Start Date</th>
                                    <th nowrap>End Date</th>
                                    <th nowrap>Creation Date</th>
                                    <th nowrap >Last Updated Date</th>
                                    <th nowrap>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(count($buyerOrders) > 0): ?>
                                <?php $__currentLoopData = $buyerOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyerOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td nowrap><?php echo e($buyerOrder->code); ?> </td>
                                    <td nowrap><?php echo e($buyerOrder->buyer->name); ?> </td>
                                    <td nowrap><?php echo e($buyerOrder->commodity->name); ?></td>
                                    <td nowrap>&#8358;<?php echo e(number_format($buyerOrder->coupon_price)); ?></td>
                                    <td nowrap><?php echo e(number_format($buyerOrder->quantity,2)); ?></td>
                                    <td nowrap><?php echo e($buyerOrder->state->name); ?></td>
                                    <td ><?php echo e($buyerOrder->delivery_location); ?></td>
                                    <td nowrap><?php echo e($buyerOrder->start_date); ?></td>
                                    <td nowrap><?php echo e($buyerOrder->end_date); ?></td>
                                    <td ><?php echo e($buyerOrder->created_at); ?></td>
                                    <td ><?php echo e($buyerOrder->updated_at); ?></td>
                                    <td nowrap><a href="<?php echo e(route('order.edit',$buyerOrder)); ?>" class="btn btn-sm btn-info" 
                                        data-toggle="tooltip" data-placement="top" title="Edit Order">
                                            <i class="fa fa-edit"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="10" style="text-align: center;">
                                        No Records Found
                                    </td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/order/index.blade.php ENDPATH**/ ?>