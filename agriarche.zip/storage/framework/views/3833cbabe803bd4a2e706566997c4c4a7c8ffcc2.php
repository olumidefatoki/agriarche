
<?php $__env->startSection('title'); ?>
Order Details | Agriarche 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>                    
                    <li><a href="#">Order</a></li>
                    <li class="active">Detail</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <h2 class="panel-title">Order</h2>                                                                   
                                </div>
                                <div class="col-md-2"></div>
                                <div class="col-md-6">
                                <div class=" panel-body">
                                    <table class="table table-bordered table-striped">
                                    <tbody>
                                            <tr>
                                                <td width="50%">Code</td>
                                                <td><?php echo e($buyerOrder->Code); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Buyer Name</td>
                                                <td><?php echo e($buyerOrder->buyer->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Commodity</td>
                                                <td><?php echo e($buyerOrder->commodity->name); ?></td>
                                            </tr> 
                                            <tr>
                                            <tr>
                                                <td>Quantity order</td>
                                                <td><?php echo e($buyerOrder->quantity); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Quantity Delviery</td>
                                                <td></td>
                                            </tr>                                              
                                            <tr>
                                                <td>Quantity Balance</td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>Completion Status(%)</td>
                                                <td></td>
                                            </tr>  
                                            <tr>
                                                <td>Price</td>
                                                <td><?php echo e($buyerOrder->price); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>State</td>
                                                <td><?php echo e($buyerOrder->state->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Delivery Location</td>
                                                <td><?php echo e($buyerOrder->delivery_location); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Duration</td>
                                                <td></td>
                                            </tr> 
                                            <tr>
                                                <td>Start Date</td>
                                                <td><?php echo e($buyerOrder->start_date); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>End Date</td>
                                                <td><?php echo e($buyerOrder->end_date); ?></td>
                                            </tr>  
                                            <tr>
                                                <td>Created Date</td>
                                                <td><?php echo e($buyerOrder->created_at); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Last Updated Date</td>
                                                <td><?php echo e($buyerOrder->updated_at); ?></td>
                                            </tr> 
                                                                                    
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->
                        </div>                        
                    </div>                                
                    
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/order/show.blade.php ENDPATH**/ ?>