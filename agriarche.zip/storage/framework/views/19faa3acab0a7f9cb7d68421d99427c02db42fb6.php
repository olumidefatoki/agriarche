
<?php $__env->startSection('title'); ?>
Buyer | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
<li><a href=active>Buyer</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Buyer</h3>
                    <ul class="panel-controls">
                        <a href="<?php echo e(route('buyer.create')); ?>">
                            <button class="m-0 btn btn-success" style="float:right;">Add New Buyer </button>
                        </a>
                    </ul>
                </div>
                <div class="panel-body">
                    <div style="overflow-x:auto;">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th nowrap>Buyer Name</th>
                                    <th nowrap>Buyer Address</th>
                                    <th nowrap>Contact Person Name</th>
                                    <th nowrap>Phone Number</th>
                                    <th nowrap>Contact Person Email</th>
                                    <th nowrap>State</th>
                                    <th nowrap>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td nowrap><?php echo e($buyer->name); ?> </td>
                                    <td nowrap><?php echo e($buyer->address); ?> </td>
                                    <td><?php echo e($buyer->contact_person_first_name); ?> , <?php echo e($buyer->contact_person_last_name); ?></td>
                                    <td nowrap><?php echo e($buyer->contact_person_phone_number); ?></td>
                                    <td nowrap><?php echo e($buyer->contact_person_email); ?></td>
                                    <td nowrap><?php echo e($buyer->state->name); ?></td>
                                    <td nowrap><a href="<?php echo e(route('buyer.edit',$buyer->id)); ?>"><i class="fa fa-edit"></i> </a>
                                    </td>

                                   
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <?php echo e($buyers->links()); ?>

                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/buyer/index.blade.php ENDPATH**/ ?>