
<?php $__env->startSection('title'); ?>
Aggregator Detail | Agriarche 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>                    
                    <li><a href="#">Aggregator</a></li>
                    <li class="active">Detail</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <h2 class="panel-title">Aggregator</h2>                                                                   
                                </div>
                                <div class="col-md-2"></div>
                                <div class="col-md-6">
                                <div class=" panel-body">
                                    <table class="table table-bordered table-striped">
                                    <tbody>
                                            <tr>
                                                <td width="50%">Aggregator Name</td>
                                                <td><?php echo e($aggregator->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Address</td>
                                                <td><?php echo e($aggregator->address); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person First Name</td>
                                                <td><?php echo e($aggregator->contact_person_first_name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person Last Name</td>
                                                <td><?php echo e($aggregator->contact_person_last_name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person Email</td>
                                                <td><?php echo e($aggregator->contact_person_email); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Contact Person Phone Number</td>
                                                <td><?php echo e($aggregator->contact_person_phone_number); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>State</td>
                                                <td><?php echo e($aggregator->state->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Bank</td>
                                                <td><?php echo e($aggregator->bank->name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Account Name</td>
                                                <td><?php echo e($aggregator->account_name); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Account Number</td>
                                                <td><?php echo e($aggregator->account_number); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Created Date</td>
                                                <td><?php echo e($aggregator->created_at); ?></td>
                                            </tr> 
                                            <tr>
                                                <td>Last Updated Date</td>
                                                <td><?php echo e($aggregator->account_number); ?></td>
                                            </tr> 
                                                                                    
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                            <!-- END DEFAULT DATATABLE -->
                        </div>                        
                    </div>                                
                    
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/aggregator/show.blade.php ENDPATH**/ ?>