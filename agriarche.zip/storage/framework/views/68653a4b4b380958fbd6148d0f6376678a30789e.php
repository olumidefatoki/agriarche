
<?php $__env->startSection('title'); ?>
Delivery details | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>
<li><a href="#">Delivery</a></li>
<li class="active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h2 class="panel-title">Delivery</h2>
                </div>
                <div class="col-md-11">
                    <div class=" panel-body">
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <td width="40%">Buyer</td>
                                    <td><?php echo e($delivery->logistics->buyerOrder->buyer->name); ?></td>
                                </tr>
                                <tr>
                                    <td >Delivery State</td>
                                    <td><?php echo e($delivery->logistics->buyerOrder->state->name); ?></td>
                                </tr>
                                <tr>
                                    <td >Aggregator</td>
                                    <td><?php echo e($delivery->logistics->aggregator->name); ?></td>
                                </tr>
                                <tr>
                                    <td >Commodity</td>
                                    <td><?php echo e($delivery->logistics->buyerOrder->commodity->name); ?></td>
                                </tr>
                                <tr>
                                    <td >Logistics Company</td>
                                    <td><?php echo e($delivery->logistics->logisticsCompany->name); ?></td>
                                </tr>
                                <tr>
                                    <td >Total Amount</td>
                                    <td>&#8358; <?php echo e(number_format($delivery->quantity_of_bags_accepted * $delivery->strike_price,2)); ?></td>
                                </tr>
                                <tr>
                                    <td >Payable Amount</td>
                                    <td>&#8358; <?php echo e(number_format($delivery->quantity_of_bags_accepted * ($delivery->strike_price - $delivery->discounted_price),2)); ?></td>
                                </tr>
                                <tr>
                                    <td >Payable Amount</td>
                                    <td>&#8358; <?php echo e(number_format($delivery->quantity_of_bags_rejected * $delivery->strike_price,2)); ?></td>
                                </tr>
                                <tr>
                                    <td >Quantity Delivered(KG)</td>
                                    <td><?php echo e(number_format($delivery->quantity_of_bags_accepted,2)); ?></td>
                                </tr>                               
                                <tr>
                                    <td >Numbers of Bags Rejected</td>
                                    <td><?php echo e(number_format($delivery->number_of_bags_rejected)); ?></td>
                                </tr>
                                <tr>
                                    <td >Status</td>
                                    <td><?php echo e($delivery->status->name); ?></td>
                                </tr>
                                <tr>
                                    <td >Waybill</td>
                                    <td><img src="<?php echo e(asset('/storage'.$delivery->waybill)); ?>" width="400" height="400"/></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- END DEFAULT DATATABLE -->
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/delivery/show.blade.php ENDPATH**/ ?>