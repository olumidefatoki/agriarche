
<?php $__env->startSection('title'); ?>
Update Delivery | Agriarche
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li><a href="">Home</a></li>
<li><a href="#">Delivery </a></li>
<li class="active">Update</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">

            <div class="block">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><strong>Delivery</strong></h3>

                    </div>
                    <div class="panel-body">
                        <form  class="form-horizontal" method="post" action="<?php echo e(route('delivery.update',$delivery)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PATCH'); ?>      
                        <?php echo csrf_field(); ?>
                            <?php echo $__env->make('partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Truck No</label>
                                <div class="col-md-6">
                                    <select class="form-control select" name="truck_number">
                                        <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($logistic->id); ?>"><?php echo e($logistic->truck_number); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['discounted_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Discounted Price:</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="discounted_price" class="form-control" value="<?php echo e($delivery->discounted_price); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['number_of_bags_accepted'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Number Of Bags Accepted:</label>
                                <div class="col-md-6 ">
                                    <input type="text" name="number_of_bags_accepted" class="form-control" value="<?php echo e($delivery->number_of_bags_accepted); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['quantity_of_bags_accepted'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Qty Of Bags Accepted(kg):</label>
                                <div class="col-md-6">
                                    <input type="text" name="quantity_of_bags_accepted" class="form-control" value="<?php echo e($delivery->quantity_of_bags_accepted); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['number_of_bags_rejected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Number Of Bags Rejected:</label>
                                <div class="col-md-6">
                                    <input type="text" name="number_of_bags_rejected" class="form-control" value="<?php echo e($delivery->number_of_bags_rejected); ?>" />
                                </div>
                            </div>
                            <div class="form-group <?php $__errorArgs = ['quantity_of_bags_rejected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Qty Of Bags Rejected(kg):</label>
                                <div class="col-md-6">
                                    <input type="text" name="quantity_of_bags_rejected" class="form-control" value="<?php echo e($delivery->quantity_of_bags_rejected); ?>" />
                                </div>
                            </div>

                            <div class="form-group <?php $__errorArgs = ['waybill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error has-feedback <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="col-md-3 control-label">Waybill:</label>
                                <div class="col-md-6">
                                <input name = 'waybill' type="file" multiple id="file-simple" class="form-control"/>
                                </div>
                            </div>

                            <div class="btn-group pull-right">
                                <button class="btn btn-success" type="submit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

    </div>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/fileinput/fileinput.min.js')); ?>"></script>        

    <script>
            $(function(){
                $("#file-simple").fileinput({
                        showUpload: false,
                        showCaption: false,
                        browseClass: "btn btn-danger",
                        fileType: "any"
                });                
            });            
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/delivery/edit.blade.php ENDPATH**/ ?>