<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- META SECTION -->
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <link rel="icon" href="favicon.ico" type="image/x-icon" />
        <!-- END META SECTION -->

        <!-- CSS INCLUDE -->
        <link rel="stylesheet" type="text/css" id="theme" href="<?php echo e(URL::to('css/theme-blue.css')); ?>"/>
        <!-- EOF CSS INCLUDE -->
    </head>
    <body class="">
        <!-- START PAGE CONTAINEcontentR -->
        <div class="page-container page-navigation-top-fixed">

            <!-- START PAGE SIDEBAR -->
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- END PAGE SIDEBAR -->

            <!-- PAGE CONTENT -->
            <div class="page-content">

                <!-- START X-NAVIGATION VERTICAL -->
                <?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END X-NAVIGATION VERTICAL -->

                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                <?php echo $__env->yieldContent('breadcrumb'); ?>
                </ul>
                <!-- END BREADCRUMB -->
                <?php echo $__env->yieldContent('content'); ?>
                <!-- PAGE CONTENT WRAPPER -->
                
                <!-- END PAGE CONTENT WRAPPER -->
            </div>
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <!-- MESSAGE BOX-->
        <?php echo $__env->make('partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END MESSAGE BOX-->

       
    <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/jquery/jquery.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/jquery/jquery-ui.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/bootstrap/bootstrap.min.js')); ?>"></script>
        <!-- END PLUGINS -->

        <!-- START THIS PAGE PLUGINS-->
        <script type='text/javascript' src="<?php echo e(URL::to('js/plugins/icheck/icheck.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(URL::to('js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>
        <!-- END THIS PAGE PLUGINS-->

        <!-- START TEMPLATE -->

        <script type="text/javascript" src="<?php echo e(URL::to('js/plugins.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(URL::to('js/actions.js')); ?>"></script>
        <?php echo $__env->yieldContent('dashboardscript'); ?>
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS -->
    </body>
</html>
<?php /**PATH C:\Users\olumide.fatoki\OneDrive\Projects\Laravel\agriarche\resources\views/layouts/master.blade.php ENDPATH**/ ?>